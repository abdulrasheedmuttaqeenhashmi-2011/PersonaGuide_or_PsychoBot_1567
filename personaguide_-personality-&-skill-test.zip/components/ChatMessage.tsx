import React from 'react';
import { Message, Sender } from '../types';

interface ChatMessageProps {
  message: Message;
}

const BotAvatar: React.FC = () => (
  <div className="w-8 h-8 rounded-full bg-cyan-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
    PG
  </div>
);

const UserAvatar: React.FC = () => (
  <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
    U
  </div>
);

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isBot = message.sender === Sender.Bot;

  return (
    <div className={`flex items-start gap-3 my-4 ${isBot ? 'justify-start' : 'justify-end'}`}>
      {isBot && <BotAvatar />}
      <div
        className={`max-w-md lg:max-w-xl p-3 rounded-xl shadow-md ${
          isBot ? 'bg-gray-700 text-gray-200 rounded-tl-none' : 'bg-cyan-600 text-white rounded-br-none'
        }`}
      >
        <div className="prose prose-sm leading-relaxed prose-invert">{message.text}</div>
      </div>
      {!isBot && <UserAvatar />}
    </div>
  );
};

export default ChatMessage;