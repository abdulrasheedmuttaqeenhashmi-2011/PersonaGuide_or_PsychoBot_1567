import React from 'react';

interface OptionButtonProps {
  text: string;
  onClick: (text: string) => void;
  disabled: boolean;
}

const OptionButton: React.FC<OptionButtonProps> = ({ text, onClick, disabled }) => {
  return (
    <button
      onClick={() => onClick(text)}
      disabled={disabled}
      className="w-full text-left bg-gray-800 border border-gray-600 rounded-lg p-3 text-cyan-200 hover:bg-gray-700 hover:border-cyan-500 focus:ring-2 focus:ring-cyan-400 focus:outline-none transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-900 disabled:text-gray-500"
    >
      {text}
    </button>
  );
};

export default OptionButton;