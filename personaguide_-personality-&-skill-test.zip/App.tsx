import React, { useState, useEffect, useRef } from 'react';
import { Message, Sender, Report } from './types';
import { QUESTIONS } from './constants';
import { generateReport } from './services/geminiService';
import ChatMessage from './components/ChatMessage';
import TypingIndicator from './components/TypingIndicator';
import OptionButton from './components/OptionButton';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [testState, setTestState] = useState<'initial' | 'ongoing' | 'analyzing' | 'finished'>('initial');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<string[]>([]);
  const [isBotTyping, setIsBotTyping] = useState(false);
  const [savedReportExists, setSavedReportExists] = useState(false);
  const [isReportSaved, setIsReportSaved] = useState(false);
  const [currentReport, setCurrentReport] = useState<Report | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages, isBotTyping]);

  const addMessage = (text: string | React.ReactNode, sender: Sender) => {
    setMessages(prev => [...prev, { id: Date.now() + Math.random(), text, sender }]);
  };

  useEffect(() => {
    const savedReportJSON = localStorage.getItem('personaGuideReport');
    if (savedReportJSON) {
      setSavedReportExists(true);
      addMessage("Welcome back! I see you have a saved report. What would you like to do?", Sender.Bot);
    } else {
      addMessage(
          <div>
              <h1 className="text-xl font-bold mb-2">👋 Hi there! I’m PersonaGuide.</h1>
              <p>I’ll ask you a few quick questions to discover your strengths, preferences, and ideal career directions.</p>
              <p className="mt-2">Ready to begin your self-discovery journey?</p>
          </div>,
          Sender.Bot
      );
    }
  }, []);

  const startTest = (fromButton: boolean = true) => {
    if (fromButton) {
      addMessage("Let's begin! 🚀", Sender.User);
    }
    setTestState('ongoing');
    setIsBotTyping(true);
    setTimeout(() => {
      setIsBotTyping(false);
      addMessage(
        <div>
          <p>{QUESTIONS[0].text}</p>
          <div className="mt-3 space-y-2">
            {QUESTIONS[0].options.map(option => (
              <OptionButton key={option} text={option} onClick={handleOptionClick} disabled={false} />
            ))}
          </div>
        </div>,
        Sender.Bot
      );
    }, 1000);
  };
  
  const handleOptionClick = (answer: string) => {
    addMessage(answer, Sender.User);
    const updatedAnswers = [...userAnswers, answer];
    setUserAnswers(updatedAnswers);

    const nextQuestionIndex = currentQuestionIndex + 1;

    if (nextQuestionIndex < QUESTIONS.length) {
      setCurrentQuestionIndex(nextQuestionIndex);
      setIsBotTyping(true);
      setTimeout(() => {
        setIsBotTyping(false);
        addMessage(
          <div>
            <p>{QUESTIONS[nextQuestionIndex].text}</p>
            <div className="mt-3 space-y-2">
              {QUESTIONS[nextQuestionIndex].options.map(option => (
                <OptionButton key={option} text={option} onClick={handleOptionClick} disabled={false} />
              ))}
            </div>
          </div>,
          Sender.Bot
        );
      }, 1200);
    } else {
      setTestState('analyzing');
      analyzeResults(updatedAnswers);
    }
  };

  const analyzeResults = async (finalAnswers: string[]) => {
    setIsBotTyping(true);
    addMessage("Great, thanks! Analyzing your responses now. This might take a moment...", Sender.Bot);
    try {
      const report = await generateReport(finalAnswers);
      setCurrentReport(report);
      displayReport(report);
    } catch (error) {
      addMessage((error as Error).message, Sender.Bot);
    } finally {
      setIsBotTyping(false);
      setTestState('finished');
    }
  };

  const displayReport = (report: Report) => {
    const messageDelay = 1500;
    
    setTimeout(() => addMessage(
        <div>
            <h2 className="font-bold text-lg">Your Personality Profile: {report.personalityType}</h2>
            <p>{report.summary}</p>
        </div>,
        Sender.Bot
    ), messageDelay);

    setTimeout(() => addMessage(
        <div>
            <h3 className="font-bold">🎯 Key Strengths</h3>
            <ul className="list-disc list-inside ml-1">
                {report.strengths.map(s => <li key={s}>{s}</li>)}
            </ul>
        </div>,
        Sender.Bot
    ), messageDelay * 2);
    
    setTimeout(() => addMessage(
        <div>
            <h3 className="font-bold">🌱 Areas for Growth</h3>
            <ul className="list-disc list-inside ml-1">
                {report.improvementAreas.map(a => <li key={a}>{a}</li>)}
            </ul>
        </div>,
        Sender.Bot
    ), messageDelay * 3);

    setTimeout(() => addMessage(
        <div>
            <h3 className="font-bold">💡 Career & Activity Suggestions</h3>
            <ul className="space-y-2 mt-1">
                {report.careerSuggestions.map(c => <li key={c.name}><strong>{c.name}:</strong> {c.reason}</li>)}
            </ul>
        </div>,
        Sender.Bot
    ), messageDelay * 4);

    setTimeout(() => addMessage(report.motivationalMessage, Sender.Bot), messageDelay * 5);
  };

  const handleViewSavedReport = () => {
    const savedReportJSON = localStorage.getItem('personaGuideReport');
    if (savedReportJSON) {
      const savedReport: Report = JSON.parse(savedReportJSON);
      setMessages([]); // Clear "welcome back"
      setTimeout(() => {
        addMessage("Here is your saved report:", Sender.Bot);
        setCurrentReport(savedReport);
        displayReport(savedReport);
        setTestState('finished');
        setIsReportSaved(true);
        setSavedReportExists(false);
      }, 300);
    }
  };

  const handleStartNewTest = () => {
    localStorage.removeItem('personaGuideReport');
    setSavedReportExists(false);
    setIsReportSaved(false);
    setCurrentReport(null);
    setUserAnswers([]);
    setCurrentQuestionIndex(0);
    setMessages([]);
    setTimeout(() => startTest(false), 300);
  };

  const saveReport = () => {
    if (currentReport) {
      localStorage.setItem('personaGuideReport', JSON.stringify(currentReport));
      setIsReportSaved(true);
      addMessage("Your report has been saved successfully! ✨ You can view it next time you visit.", Sender.Bot);
    }
  };
  
  return (
    <div className="flex flex-col h-screen bg-gray-900 text-gray-200 font-sans">
      <header className="bg-gray-800 border-b border-gray-700 p-4">
        <h1 className="text-2xl font-bold text-center text-cyan-400">PersonaGuide Chatbot</h1>
      </header>
      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-3xl mx-auto">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
          ))}
          {isBotTyping && (
             <div className="flex justify-start gap-3 my-4">
               <div className="w-8 h-8 rounded-full bg-cyan-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">PG</div>
               <div className="bg-gray-700 rounded-xl rounded-tl-none p-2 shadow-md">
                 <TypingIndicator />
               </div>
             </div>
          )}
          <div ref={chatEndRef} />
        </div>
      </main>
      <footer className="bg-gray-800 p-4 border-t border-gray-700">
        <div className="max-w-3xl mx-auto">
          {testState === 'initial' && savedReportExists && (
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={handleViewSavedReport}
                className="w-full bg-cyan-500 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-cyan-600 transition-colors duration-200"
              >
                View Saved Report
              </button>
              <button
                onClick={handleStartNewTest}
                className="w-full bg-gray-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-gray-700 transition-colors duration-200"
              >
                Start New Test
              </button>
            </div>
          )}
          {testState === 'initial' && !savedReportExists && (
            <button
              onClick={() => startTest(true)}
              className="w-full bg-cyan-500 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-cyan-600 transition-colors duration-200"
            >
              Start the Test
            </button>
          )}
          {testState === 'ongoing' && (
             <p className="text-center text-gray-400 text-sm">Select an option above to continue...</p>
          )}
          {testState === 'analyzing' && (
             <p className="text-center text-gray-400 text-sm animate-pulse">Analyzing your results...</p>
          )}
          {testState === 'finished' && !isReportSaved && (
             <button
                onClick={saveReport}
                className="w-full bg-cyan-500 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-cyan-600 transition-colors duration-200"
             >
                Save Your Report
             </button>
          )}
          {testState === 'finished' && isReportSaved && (
             <button
                className="w-full bg-gray-700 text-gray-400 font-bold py-3 px-4 rounded-lg cursor-not-allowed"
                disabled
             >
                Report Saved
             </button>
          )}
        </div>
      </footer>
    </div>
  );
};

export default App;
