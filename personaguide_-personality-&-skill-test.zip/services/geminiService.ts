
import { GoogleGenAI, Type } from "@google/genai";
import { QUESTIONS } from '../constants';
import { Report } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const reportSchema = {
  type: Type.OBJECT,
  properties: {
    personalityType: {
      type: Type.STRING,
      description: "A concise personality type name (e.g., 'Analytical Planner', 'Creative Visionary', 'Empathetic Connector')."
    },
    summary: {
      type: Type.STRING,
      description: "A short, one-paragraph summary of the user's personality based on their answers."
    },
    strengths: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of 2-3 key strengths."
    },
    improvementAreas: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of 2-3 potential areas for growth, framed constructively."
    },
    careerSuggestions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "The name of the career path." },
          reason: { type: Type.STRING, description: "A brief explanation of why this career aligns with their personality." }
        },
        required: ["name", "reason"]
      },
      description: "A list of 3-5 suitable career paths."
    },
    motivationalMessage: {
      type: Type.STRING,
      description: "A final, short, and encouraging message for the user."
    }
  },
  required: ["personalityType", "summary", "strengths", "improvementAreas", "careerSuggestions", "motivationalMessage"]
};

export async function generateReport(answers: string[]): Promise<Report> {
  const prompt = `
    You are PersonaGuide, an intelligent and empathetic Personality & Skill Assessment Chatbot for students. Your tone is friendly, motivating, and professional.

    A student has answered the following questions about their personality and skills:
    ${QUESTIONS.map((q, i) => `Question ${i + 1}: ${q.text}\nAnswer ${i + 1}: ${answers[i]}`).join('\n\n')}

    Based on these answers, generate a personalized report. Your response MUST be a JSON object that adheres to the provided schema.

    The report should include:
    1. A short, catchy name for their personality type.
    2. A brief summary of their personality.
    3. 2-3 key strengths.
    4. 2-3 areas for improvement, phrased positively as "areas for growth".
    5. 3-5 suggested career paths with brief reasons.
    6. A short, final motivational message.

    Use simple, clear, and encouraging language that a student can easily understand. Focus on positive growth.
  `;
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: reportSchema,
      },
    });

    const jsonText = response.text.trim();
    const reportData = JSON.parse(jsonText);
    
    // Basic validation to ensure the parsed object matches the expected structure
    if (
      !reportData.personalityType || 
      !reportData.summary || 
      !Array.isArray(reportData.strengths) ||
      !Array.isArray(reportData.improvementAreas) ||
      !Array.isArray(reportData.careerSuggestions) ||
      !reportData.motivationalMessage
      ) {
        throw new Error("Invalid report structure received from API.");
    }
      
    return reportData as Report;

  } catch (error) {
    console.error("Error generating report:", error);
    throw new Error("Sorry, I had trouble analyzing your results. Please try again later.");
  }
}
