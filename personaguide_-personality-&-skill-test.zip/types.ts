import React from 'react';

export enum Sender {
  User = 'user',
  Bot = 'bot',
}

export interface Message {
  id: number;
  text: string | React.ReactNode;
  sender: Sender;
}

export interface Question {
  text: string;
  options: string[];
}

export interface CareerSuggestion {
  name: string;
  reason: string;
}

export interface Report {
  personalityType: string;
  summary: string;
  strengths: string[];
  improvementAreas: string[];
  careerSuggestions: CareerSuggestion[];
  motivationalMessage: string;
}
