
import { Question } from './types';

export const QUESTIONS: Question[] = [
  {
    text: "When working on a group project, what role do you naturally take on?",
    options: ["The leader who organizes and delegates tasks.", "The creative one who brainstorms new ideas.", "The supporter who helps others and ensures harmony.", "The analyst who focuses on details and accuracy."],
  },
  {
    text: "You have a free weekend. How do you prefer to spend it?",
    options: ["Planning and organizing my week ahead.", "Starting a new creative project like painting or writing.", "Spending quality time with friends and family.", "Learning something new, like a documentary or a course."],
  },
  {
    text: "How do you approach a difficult problem?",
    options: ["Break it down into smaller, logical steps.", "Think outside the box for a unique solution.", "Talk it through with someone to get their perspective.", "Research thoroughly to understand all aspects."],
  },
  {
    text: "Which academic subject area do you feel most drawn to?",
    options: ["Math or Science - I love logic and facts.", "Arts or Literature - I enjoy expressing creativity.", "Social Studies or Psychology - I'm fascinated by people.", "Computer Science or Engineering - I like building and fixing things."],
  },
  {
    text: "When faced with unexpected stress or a tight deadline, what's your first reaction?",
    options: ["Stay calm and focus on a clear plan of action.", "Feel a burst of energy and find a creative workaround.", "Seek support from friends or mentors to stay positive.", "Double-check all my work to avoid mistakes."],
  },
];
