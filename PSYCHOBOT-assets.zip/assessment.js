// Assessment State Management
let assessmentState = {
    currentPhase: 'personality', // 'personality' or 'skills'
    currentQuestionIndex: 0,
    responses: {},
    userName: '',
    userAge: '',
    startTime: null,
    endTime: null
};

// Calculate total questions
const totalPersonalityQuestions = assessmentData.bigFiveQuestions.length;
const totalSkillsQuestions = assessmentData.skillsQuestions.length;
const totalQuestions = totalPersonalityQuestions + totalSkillsQuestions;

function startAssessment() {
    const userName = document.getElementById('username').value.trim();
    const userAge = document.getElementById('age').value;

    if (!userName) {
        alert('Please enter your name to continue 😊');
        return;
    }

    if (!userAge) {
        alert('Please select your age group to continue 😊');
        return;
    }

    assessmentState.userName = userName;
    assessmentState.userAge = userAge;
    assessmentState.startTime = new Date();

    showScreen('assessment-screen');
    loadQuestion();
}

function loadQuestion() {
    let question;
    let questionNumber;

    if (assessmentState.currentPhase === 'personality') {
        question = assessmentData.bigFiveQuestions[assessmentState.currentQuestionIndex];
        questionNumber = assessmentState.currentQuestionIndex + 1;
        document.getElementById('section-title').innerHTML = `<i class="fas fa-brain"></i> Personality Assessment`;
    } else {
        question = assessmentData.skillsQuestions[assessmentState.currentQuestionIndex];
        questionNumber = totalPersonalityQuestions + assessmentState.currentQuestionIndex + 1;
        document.getElementById('section-title').innerHTML = `<i class="fas fa-tools"></i> Skills Assessment`;
    }

    // Update progress
    const progress = (questionNumber / totalQuestions) * 100;
    document.getElementById('progress-fill').style.width = progress + '%';
    document.getElementById('progress-text').textContent = Math.round(progress) + '%';

    // Display question
    document.getElementById('question-text').textContent = question.question;
    document.getElementById('question-info').textContent = `Question ${questionNumber} of ${totalQuestions}`;

    // Display answer options
    displayAnswerOptions(question.id);

    // Update navigation buttons
    updateNavigationButtons();
}

function displayAnswerOptions(questionId) {
    const optionsContainer = document.getElementById('answer-options');
    optionsContainer.innerHTML = '';

    likertOptions.forEach(option => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'answer-option';

        if (assessmentState.responses[questionId] === option.value) {
            optionDiv.classList.add('selected');
        }

        optionDiv.innerHTML = `
            <input type="radio" 
                   name="answer" 
                   id="option-${option.value}" 
                   value="${option.value}"
                   ${assessmentState.responses[questionId] === option.value ? 'checked' : ''}>
            <label for="option-${option.value}">${option.label}</label>
        `;

        optionDiv.addEventListener('click', () => selectAnswer(questionId, option.value));
        optionsContainer.appendChild(optionDiv);
    });
}

function selectAnswer(questionId, value) {
    assessmentState.responses[questionId] = value;

    // Update visual selection
    document.querySelectorAll('.answer-option').forEach(opt => {
        opt.classList.remove('selected');
    });

    const selectedOption = document.querySelector(`input[value="${value}"]`).closest('.answer-option');
    selectedOption.classList.add('selected');

    // Enable next button
    document.getElementById('next-btn').disabled = false;
}

function nextQuestion() {
    if (assessmentState.currentPhase === 'personality') {
        if (assessmentState.currentQuestionIndex < totalPersonalityQuestions - 1) {
            assessmentState.currentQuestionIndex++;
            loadQuestion();
        } else {
            // Switch to skills phase
            assessmentState.currentPhase = 'skills';
            assessmentState.currentQuestionIndex = 0;
            showPhaseTransition();
        }
    } else {
        if (assessmentState.currentQuestionIndex < totalSkillsQuestions - 1) {
            assessmentState.currentQuestionIndex++;
            loadQuestion();
        } else {
            // Complete assessment
            completeAssessment();
        }
    }
}

function previousQuestion() {
    if (assessmentState.currentQuestionIndex > 0) {
        assessmentState.currentQuestionIndex--;
        loadQuestion();
    } else if (assessmentState.currentPhase === 'skills') {
        // Go back to personality phase
        assessmentState.currentPhase = 'personality';
        assessmentState.currentQuestionIndex = totalPersonalityQuestions - 1;
        loadQuestion();
    }
}

function updateNavigationButtons() {
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');

    // Previous button
    prevBtn.disabled = (assessmentState.currentPhase === 'personality' && assessmentState.currentQuestionIndex === 0);

    // Next button
    let currentQuestionId;
    if (assessmentState.currentPhase === 'personality') {
        currentQuestionId = assessmentData.bigFiveQuestions[assessmentState.currentQuestionIndex].id;
    } else {
        currentQuestionId = assessmentData.skillsQuestions[assessmentState.currentQuestionIndex].id;
    }

    nextBtn.disabled = !assessmentState.responses[currentQuestionId];
}

function showPhaseTransition() {
    const transitionDiv = document.createElement('div');
    transitionDiv.className = 'phase-transition';
    transitionDiv.innerHTML = `
        <div style="text-align: center; padding: 60px; background: var(--bg-light); border-radius: 12px; margin: 40px 0;">
            <i class="fas fa-check-circle" style="font-size: 4rem; color: var(--success-color); margin-bottom: 20px;"></i>
            <h2 style="font-size: 2rem; margin-bottom: 15px;">Great Job! 🎉</h2>
            <p style="font-size: 1.2rem; color: var(--text-secondary); margin-bottom: 30px;">
                Personality assessment complete! Now let's evaluate your skills.
            </p>
            <button class="btn-primary" onclick="continueToSkills()">
                Continue to Skills Assessment <i class="fas fa-arrow-right"></i>
            </button>
        </div>
    `;

    document.querySelector('.assessment-header').after(transitionDiv);
    document.querySelector('.chat-container').style.display = 'none';
    document.querySelector('.answer-options').style.display = 'none';
    document.querySelector('.navigation-buttons').style.display = 'none';
}

function continueToSkills() {
    document.querySelector('.phase-transition')?.remove();
    document.querySelector('.chat-container').style.display = 'flex';
    document.querySelector('.answer-options').style.display = 'flex';
    document.querySelector('.navigation-buttons').style.display = 'flex';
    loadQuestion();
}

function completeAssessment() {
    assessmentState.endTime = new Date();
    const timeTaken = Math.round((assessmentState.endTime - assessmentState.startTime) / 1000 / 60);

    console.log(`Assessment completed in ${timeTaken} minutes`);
    console.log('Responses:', assessmentState.responses);

    // Calculate results
    calculateResults();

    // Show results screen
    showScreen('results-screen');
}

function calculateResults() {
    // Calculate Big Five personality scores
    const personalityScores = calculatePersonalityScores();

    // Calculate skills scores
    const skillsScores = calculateSkillsScores();

    // Match careers
    const careerMatches = matchCareers(personalityScores, skillsScores);

    // Store results
    assessmentState.results = {
        personality: personalityScores,
        skills: skillsScores,
        careers: careerMatches
    };

    // Display results
    displayResults();
}

function calculatePersonalityScores() {
    const scores = {
        openness: 0,
        conscientiousness: 0,
        extraversion: 0,
        agreeableness: 0,
        neuroticism: 0
    };

    const counts = { ...scores };

    assessmentData.bigFiveQuestions.forEach(q => {
        if (assessmentState.responses[q.id]) {
            let score = assessmentState.responses[q.id];

            // Neuroticism is reverse scored for emotional stability
            if (q.trait === 'neuroticism') {
                score = 6 - score; // Convert to emotional stability
            }

            scores[q.trait] += score;
            counts[q.trait]++;
        }
    });

    // Calculate percentages
    Object.keys(scores).forEach(trait => {
        scores[trait] = Math.round((scores[trait] / (counts[trait] * 5)) * 100);
    });

    return scores;
}

function calculateSkillsScores() {
    const scores = {
        problem_solving: 0,
        communication: 0,
        leadership: 0,
        technical: 0
    };

    const counts = { ...scores };

    assessmentData.skillsQuestions.forEach(q => {
        if (assessmentState.responses[q.id]) {
            scores[q.skill] += assessmentState.responses[q.id];
            counts[q.skill]++;
        }
    });

    // Calculate percentages
    Object.keys(scores).forEach(skill => {
        if (counts[skill] > 0) {
            scores[skill] = Math.round((scores[skill] / (counts[skill] * 5)) * 100);
        }
    });

    return scores;
}

function matchCareers(personalityScores, skillsScores) {
    const matches = [];

    Object.values(assessmentData.careerFields).forEach(field => {
        field.careers.forEach(career => {
            let compatibilityScore = 0;
            let totalWeight = 0;

            // Calculate personality compatibility
            Object.keys(field.personalityFit).forEach(trait => {
                const required = field.personalityFit[trait];
                const actual = personalityScores[trait];
                const weight = 1;

                // Calculate similarity (100 - absolute difference)
                const similarity = 100 - Math.abs(required - actual);
                compatibilityScore += similarity * weight;
                totalWeight += weight;
            });

            const finalScore = Math.round(compatibilityScore / totalWeight);

            matches.push({
                field: field.name,
                career: career,
                compatibility: finalScore
            });
        });
    });

    // Sort by compatibility and return top 5
    return matches.sort((a, b) => b.compatibility - a.compatibility).slice(0, 5);
}