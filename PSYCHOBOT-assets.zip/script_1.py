
# Create index.html
html_content = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personality & Skills Assessment Chatbot</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Welcome Screen -->
        <div id="welcome-screen" class="screen active">
            <div class="welcome-content">
                <div class="logo">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <h1>Welcome to Your Career Discovery Journey! 🚀</h1>
                <p class="subtitle">Discover your strengths, explore your potential, and find the perfect career path</p>
                
                <div class="welcome-card">
                    <h2>What You'll Get:</h2>
                    <ul class="benefits-list">
                        <li><i class="fas fa-check-circle"></i> Comprehensive personality assessment based on Big Five model</li>
                        <li><i class="fas fa-check-circle"></i> Skills evaluation and strength identification</li>
                        <li><i class="fas fa-check-circle"></i> Personalized career recommendations</li>
                        <li><i class="fas fa-check-circle"></i> Downloadable development resources</li>
                        <li><i class="fas fa-check-circle"></i> Actionable insights for your future</li>
                    </ul>
                </div>

                <div class="time-estimate">
                    <i class="fas fa-clock"></i>
                    <span>Takes approximately 10-15 minutes</span>
                </div>

                <div class="input-group">
                    <label for="username">What's your name?</label>
                    <input type="text" id="username" placeholder="Enter your name" />
                </div>

                <div class="input-group">
                    <label for="age">Your age:</label>
                    <select id="age">
                        <option value="">Select your age</option>
                        <option value="13-15">13-15 years</option>
                        <option value="16-18">16-18 years</option>
                        <option value="19-22">19-22 years</option>
                        <option value="23+">23+ years</option>
                    </select>
                </div>

                <button class="btn-primary" onclick="startAssessment()">
                    Start Your Assessment <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>

        <!-- Assessment Screen -->
        <div id="assessment-screen" class="screen">
            <div class="assessment-header">
                <h2 id="section-title">Personality Assessment</h2>
                <div class="progress-container">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progress-fill"></div>
                    </div>
                    <span class="progress-text" id="progress-text">0%</span>
                </div>
            </div>

            <div class="chat-container">
                <div class="chatbot-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="question-container">
                    <div class="question-text" id="question-text"></div>
                    <div class="question-info" id="question-info"></div>
                </div>
            </div>

            <div class="answer-options" id="answer-options">
                <!-- Likert scale options will be inserted here -->
            </div>

            <div class="navigation-buttons">
                <button class="btn-secondary" id="prev-btn" onclick="previousQuestion()" disabled>
                    <i class="fas fa-arrow-left"></i> Previous
                </button>
                <button class="btn-secondary" id="next-btn" onclick="nextQuestion()" disabled>
                    Next <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>

        <!-- Results Screen -->
        <div id="results-screen" class="screen">
            <div class="results-header">
                <h1>Your Personalized Assessment Report 📊</h1>
                <p class="results-subtitle">Here's what we discovered about you, <span id="user-name-result"></span>!</p>
            </div>

            <div class="results-content">
                <!-- Personality Profile -->
                <div class="result-section">
                    <h2><i class="fas fa-brain"></i> Your Personality Profile</h2>
                    <div class="personality-chart" id="personality-chart"></div>
                    <div class="trait-descriptions" id="trait-descriptions"></div>
                </div>

                <!-- Strengths and Growth Areas -->
                <div class="result-section">
                    <h2><i class="fas fa-star"></i> Your Top Strengths</h2>
                    <div id="strengths-list"></div>
                </div>

                <div class="result-section">
                    <h2><i class="fas fa-seedling"></i> Areas for Growth</h2>
                    <div id="growth-areas-list"></div>
                </div>

                <!-- Skills Assessment -->
                <div class="result-section">
                    <h2><i class="fas fa-tools"></i> Your Skills Profile</h2>
                    <div class="skills-chart" id="skills-chart"></div>
                </div>

                <!-- Career Recommendations -->
                <div class="result-section">
                    <h2><i class="fas fa-briefcase"></i> Career Recommendations</h2>
                    <p class="section-description">Based on your personality and skills, here are careers that align with your profile:</p>
                    <div id="career-recommendations"></div>
                </div>

                <!-- Resources -->
                <div class="result-section">
                    <h2><i class="fas fa-book"></i> Recommended Resources</h2>
                    <div class="resources-grid" id="resources-grid"></div>
                </div>

                <!-- Feedback Section -->
                <div class="result-section feedback-section">
                    <h2><i class="fas fa-comment-dots"></i> Help Us Improve</h2>
                    <p>How was your experience?</p>
                    <div class="rating-container">
                        <button class="rating-btn" onclick="submitRating(1)">😞</button>
                        <button class="rating-btn" onclick="submitRating(2)">😐</button>
                        <button class="rating-btn" onclick="submitRating(3)">🙂</button>
                        <button class="rating-btn" onclick="submitRating(4)">😊</button>
                        <button class="rating-btn" onclick="submitRating(5)">😍</button>
                    </div>
                    <textarea id="feedback-text" placeholder="Share your thoughts and suggestions..."></textarea>
                    <button class="btn-primary" onclick="submitFeedback()">Submit Feedback</button>
                </div>

                <div class="action-buttons">
                    <button class="btn-primary" onclick="downloadReport()">
                        <i class="fas fa-download"></i> Download Report (PDF)
                    </button>
                    <button class="btn-secondary" onclick="restartAssessment()">
                        <i class="fas fa-redo"></i> Retake Assessment
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="js/data.js"></script>
    <script src="js/assessment.js"></script>
    <script src="js/results.js"></script>
    <script src="js/app.js"></script>
</body>
</html>'''

with open('personality-chatbot-webapp/index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print("✓ Created index.html")
