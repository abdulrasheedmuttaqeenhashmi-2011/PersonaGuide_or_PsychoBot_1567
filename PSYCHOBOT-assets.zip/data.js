// Assessment Data
const assessmentData = {
    bigFiveQuestions: [
        // Openness
        {
            id: 'o1',
            trait: 'openness',
            question: 'I enjoy exploring new ideas and concepts, even if they challenge my current beliefs.',
            facet: 'ideas',
            scoring: 'positive'
        },
        {
            id: 'o2',
            trait: 'openness',
            question: 'I prefer trying creative solutions to problems rather than following established methods.',
            facet: 'actions',
            scoring: 'positive'
        },
        {
            id: 'o3',
            trait: 'openness',
            question: 'I am fascinated by art, music, or literature.',
            facet: 'aesthetics',
            scoring: 'positive'
        },
        {
            id: 'o4',
            trait: 'openness',
            question: 'I often imagine different scenarios and possibilities.',
            facet: 'fantasy',
            scoring: 'positive'
        },
        {
            id: 'o5',
            trait: 'openness',
            question: 'I enjoy learning about different cultures and their values.',
            facet: 'values',
            scoring: 'positive'
        },

        // Conscientiousness
        {
            id: 'c1',
            trait: 'conscientiousness',
            question: 'I always complete my assignments before the deadline.',
            facet: 'achievement_striving',
            scoring: 'positive'
        },
        {
            id: 'c2',
            trait: 'conscientiousness',
            question: 'I have a systematic approach to organizing my study materials.',
            facet: 'order',
            scoring: 'positive'
        },
        {
            id: 'c3',
            trait: 'conscientiousness',
            question: 'I persist in working toward my goals even when facing obstacles.',
            facet: 'self_discipline',
            scoring: 'positive'
        },
        {
            id: 'c4',
            trait: 'conscientiousness',
            question: 'I think carefully before making important decisions.',
            facet: 'deliberation',
            scoring: 'positive'
        },
        {
            id: 'c5',
            trait: 'conscientiousness',
            question: 'I feel responsible for my own success and failures.',
            facet: 'dutifulness',
            scoring: 'positive'
        },

        // Extraversion
        {
            id: 'e1',
            trait: 'extraversion',
            question: 'I feel energized after spending time with groups of people.',
            facet: 'gregariousness',
            scoring: 'positive'
        },
        {
            id: 'e2',
            trait: 'extraversion',
            question: 'I often take the lead in group projects or activities.',
            facet: 'assertiveness',
            scoring: 'positive'
        },
        {
            id: 'e3',
            trait: 'extraversion',
            question: 'I enjoy being the center of attention in social situations.',
            facet: 'excitement_seeking',
            scoring: 'positive'
        },
        {
            id: 'e4',
            trait: 'extraversion',
            question: 'I tend to be talkative and share my thoughts openly.',
            facet: 'activity',
            scoring: 'positive'
        },
        {
            id: 'e5',
            trait: 'extraversion',
            question: 'I generally feel optimistic about future outcomes.',
            facet: 'positive_emotions',
            scoring: 'positive'
        },

        // Agreeableness
        {
            id: 'a1',
            trait: 'agreeableness',
            question: 'I try to understand other people\'s perspectives before forming opinions.',
            facet: 'trust',
            scoring: 'positive'
        },
        {
            id: 'a2',
            trait: 'agreeableness',
            question: 'I prefer cooperative approaches to solving conflicts.',
            facet: 'compliance',
            scoring: 'positive'
        },
        {
            id: 'a3',
            trait: 'agreeableness',
            question: 'I often put others\' needs before my own.',
            facet: 'altruism',
            scoring: 'positive'
        },
        {
            id: 'a4',
            trait: 'agreeableness',
            question: 'I avoid being critical or harsh when giving feedback.',
            facet: 'tender_mindedness',
            scoring: 'positive'
        },
        {
            id: 'a5',
            trait: 'agreeableness',
            question: 'I tend to see the best in people rather than focusing on their flaws.',
            facet: 'straightforwardness',
            scoring: 'positive'
        },

        // Neuroticism (reversed scoring)
        {
            id: 'n1',
            trait: 'neuroticism',
            question: 'I often worry about things that might go wrong.',
            facet: 'anxiety',
            scoring: 'positive'
        },
        {
            id: 'n2',
            trait: 'neuroticism',
            question: 'I get frustrated easily when things don\'t go as planned.',
            facet: 'angry_hostility',
            scoring: 'positive'
        },
        {
            id: 'n3',
            trait: 'neuroticism',
            question: 'I sometimes feel sad or down without a clear reason.',
            facet: 'depression',
            scoring: 'positive'
        },
        {
            id: 'n4',
            trait: 'neuroticism',
            question: 'I feel self-conscious in social situations.',
            facet: 'self_consciousness',
            scoring: 'positive'
        },
        {
            id: 'n5',
            trait: 'neuroticism',
            question: 'I have difficulty controlling my impulses.',
            facet: 'impulsiveness',
            scoring: 'positive'
        }
    ],

    skillsQuestions: [
        {
            id: 's1',
            skill: 'problem_solving',
            question: 'When faced with a complex problem, I break it down into smaller, manageable parts.',
            category: 'analytical_thinking'
        },
        {
            id: 's2',
            skill: 'problem_solving',
            question: 'I can identify the root cause of problems rather than just addressing symptoms.',
            category: 'critical_thinking'
        },
        {
            id: 's3',
            skill: 'problem_solving',
            question: 'I generate multiple solutions before choosing the best approach.',
            category: 'creative_thinking'
        },
        {
            id: 's4',
            skill: 'communication',
            question: 'I can explain complex concepts in simple terms that others understand.',
            category: 'verbal_communication'
        },
        {
            id: 's5',
            skill: 'communication',
            question: 'I listen actively and ask clarifying questions during conversations.',
            category: 'listening_skills'
        },
        {
            id: 's6',
            skill: 'communication',
            question: 'I adapt my communication style based on my audience.',
            category: 'adaptability'
        },
        {
            id: 's7',
            skill: 'leadership',
            question: 'I motivate others to work toward common goals.',
            category: 'team_leadership'
        },
        {
            id: 's8',
            skill: 'leadership',
            question: 'I take initiative when situations require action.',
            category: 'initiative'
        },
        {
            id: 's9',
            skill: 'leadership',
            question: 'I help resolve conflicts between team members constructively.',
            category: 'conflict_resolution'
        },
        {
            id: 's10',
            skill: 'technical',
            question: 'I quickly learn new software tools and technologies.',
            category: 'learning_agility'
        },
        {
            id: 's11',
            skill: 'technical',
            question: 'I can troubleshoot technical problems systematically.',
            category: 'technical_troubleshooting'
        },
        {
            id: 's12',
            skill: 'technical',
            question: 'I stay updated with latest developments in my field of interest.',
            category: 'continuous_learning'
        }
    ],

    careerFields: {
        technology: {
            name: 'Technology',
            personalityFit: {
                openness: 80,
                conscientiousness: 75,
                extraversion: 50,
                agreeableness: 55,
                neuroticism: 35
            },
            careers: [
                {
                    title: 'Software Developer',
                    growth: '22%',
                    salary: '$107,510',
                    description: 'Design, develop, and maintain software applications and systems. Work with various programming languages and frameworks to create innovative solutions.'
                },
                {
                    title: 'Data Scientist',
                    growth: '35%',
                    salary: '$126,830',
                    description: 'Analyze complex data sets to extract insights and drive business decisions. Use statistical methods, machine learning, and data visualization techniques.'
                },
                {
                    title: 'Cybersecurity Analyst',
                    growth: '33%',
                    salary: '$99,730',
                    description: 'Protect computer systems and networks from cyber threats. Monitor security systems, investigate breaches, and implement protective measures.'
                }
            ]
        },
        healthcare: {
            name: 'Healthcare',
            personalityFit: {
                openness: 70,
                conscientiousness: 80,
                extraversion: 60,
                agreeableness: 85,
                neuroticism: 30
            },
            careers: [
                {
                    title: 'Registered Nurse',
                    growth: '7%',
                    salary: '$75,330',
                    description: 'Provide patient care, educate patients about health conditions, and coordinate with healthcare professionals to deliver comprehensive treatment.'
                },
                {
                    title: 'Physical Therapist',
                    growth: '18%',
                    salary: '$89,440',
                    description: 'Help patients recover from injuries and manage pain through therapeutic exercises, manual therapy, and specialized treatment plans.'
                },
                {
                    title: 'Mental Health Counselor',
                    growth: '25%',
                    salary: '$47,660',
                    description: 'Provide therapy and counseling to individuals dealing with mental health challenges, emotional issues, and life transitions.'
                }
            ]
        },
        business: {
            name: 'Business',
            personalityFit: {
                openness: 65,
                conscientiousness: 70,
                extraversion: 75,
                agreeableness: 60,
                neuroticism: 40
            },
            careers: [
                {
                    title: 'Marketing Manager',
                    growth: '10%',
                    salary: '$135,900',
                    description: 'Develop and execute marketing strategies, manage campaigns, analyze market trends, and lead marketing teams to achieve business objectives.'
                },
                {
                    title: 'Financial Analyst',
                    growth: '6%',
                    salary: '$81,590',
                    description: 'Analyze financial data, create forecasts, and provide investment recommendations to help businesses make informed financial decisions.'
                },
                {
                    title: 'Human Resources Manager',
                    growth: '9%',
                    salary: '$121,220',
                    description: 'Oversee recruitment, employee relations, compensation, and organizational development to optimize workforce effectiveness.'
                }
            ]
        },
        education: {
            name: 'Education',
            personalityFit: {
                openness: 75,
                conscientiousness: 70,
                extraversion: 65,
                agreeableness: 80,
                neuroticism: 30
            },
            careers: [
                {
                    title: 'High School Teacher',
                    growth: '8%',
                    salary: '$61,660',
                    description: 'Educate students in specific subjects, develop curriculum, assess student progress, and foster a positive learning environment.'
                },
                {
                    title: 'Instructional Designer',
                    growth: '11%',
                    salary: '$66,290',
                    description: 'Create engaging educational content, develop e-learning programs, and design effective training materials using instructional technology.'
                },
                {
                    title: 'Education Administrator',
                    growth: '8%',
                    salary: '$96,400',
                    description: 'Manage educational institutions, oversee curriculum development, coordinate staff, and ensure quality educational standards.'
                }
            ]
        },
        creative: {
            name: 'Creative Arts',
            personalityFit: {
                openness: 85,
                conscientiousness: 60,
                extraversion: 55,
                agreeableness: 70,
                neuroticism: 45
            },
            careers: [
                {
                    title: 'Graphic Designer',
                    growth: '3%',
                    salary: '$52,110',
                    description: 'Create visual concepts using computer software to communicate ideas that inspire and inform consumers through advertisements, websites, and publications.'
                },
                {
                    title: 'UX/UI Designer',
                    growth: '13%',
                    salary: '$77,200',
                    description: 'Design user-friendly interfaces for websites and applications, conduct user research, and create prototypes to enhance user experience.'
                },
                {
                    title: 'Content Creator',
                    growth: '14%',
                    salary: '$62,150',
                    description: 'Develop engaging content for various platforms including social media, blogs, videos, and podcasts to build audience engagement and brand presence.'
                }
            ]
        }
    },

    traitDescriptions: {
        openness: {
            name: 'Openness to Experience',
            high: 'You are intellectually curious, creative, and open to new experiences. You enjoy exploring ideas, appreciate art and beauty, and are comfortable with unconventional thinking.',
            medium: 'You balance tradition with innovation. You appreciate new ideas but also value practical approaches. You can be creative when needed but also pragmatic.',
            low: 'You prefer familiar routines and practical approaches. You value tradition and tend to be more conventional in your thinking and preferences.'
        },
        conscientiousness: {
            name: 'Conscientiousness',
            high: 'You are highly organized, disciplined, and goal-oriented. You plan ahead, pay attention to details, and take your responsibilities seriously.',
            medium: 'You balance structure with flexibility. You can be organized when necessary but also comfortable with spontaneity. You set goals but remain adaptable.',
            low: 'You prefer flexibility and spontaneity. You work best without rigid schedules and enjoy taking things as they come rather than extensive planning.'
        },
        extraversion: {
            name: 'Extraversion',
            high: 'You are outgoing, energetic, and thrive in social situations. You enjoy being around people, taking on leadership roles, and expressing yourself openly.',
            medium: 'You are comfortable both in social settings and alone. You can be outgoing when the situation calls for it but also value quiet time for reflection.',
            low: 'You are more reserved and introspective. You prefer smaller groups or one-on-one interactions and need time alone to recharge your energy.'
        },
        agreeableness: {
            name: 'Agreeableness',
            high: 'You are compassionate, cooperative, and prioritize harmony in relationships. You are trusting, helpful, and considerate of others\' feelings.',
            medium: 'You balance cooperation with assertiveness. You can be accommodating but also stand your ground when necessary. You value both harmony and honesty.',
            low: 'You are direct and competitive. You prioritize truth over tact and are comfortable with conflict when standing up for your beliefs and interests.'
        },
        neuroticism: {
            name: 'Emotional Stability',
            high: 'You experience emotions intensely and may be more sensitive to stress. You are in touch with your feelings and aware of potential challenges.',
            medium: 'You experience a normal range of emotions and handle stress reasonably well. You have both emotional sensitivity and resilience.',
            low: 'You are emotionally stable and resilient. You handle stress well, remain calm under pressure, and rarely experience strong negative emotions.'
        }
    },

    resources: [
        {
            title: 'Career Exploration Workbook',
            icon: 'fa-compass',
            description: 'Comprehensive guide to exploring career options, industry trends, and pathways to your dream job.'
        },
        {
            title: 'Personality Development Guide',
            icon: 'fa-user-plus',
            description: 'Strategies for personal growth, building on your strengths, and developing areas for improvement.'
        },
        {
            title: 'Skills Enhancement Toolkit',
            icon: 'fa-tools',
            description: 'Practical exercises and resources to develop technical, soft, and leadership skills.'
        },
        {
            title: 'Study Skills Handbook',
            icon: 'fa-book-open',
            description: 'Effective learning strategies, time management techniques, and productivity tips for students.'
        },
        {
            title: 'Interview Preparation Guide',
            icon: 'fa-handshake',
            description: 'Master the art of interviews with tips, common questions, and best practices for success.'
        },
        {
            title: 'Goal Setting Template',
            icon: 'fa-bullseye',
            description: 'Structured approach to setting SMART goals and creating actionable plans for achievement.'
        }
    ]
};

// Likert scale options
const likertOptions = [
    { value: 1, label: 'Strongly Disagree' },
    { value: 2, label: 'Disagree' },
    { value: 3, label: 'Neutral' },
    { value: 4, label: 'Agree' },
    { value: 5, label: 'Strongly Agree' }
];