
# Create styles.css
css_content = '''/* ===========================
   Global Styles & Reset
   =========================== */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --primary-color: #4F46E5;
    --secondary-color: #7C3AED;
    --success-color: #10B981;
    --warning-color: #F59E0B;
    --danger-color: #EF4444;
    --text-primary: #1F2937;
    --text-secondary: #6B7280;
    --bg-light: #F9FAFB;
    --bg-white: #FFFFFF;
    --border-color: #E5E7EB;
    --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    --border-radius: 12px;
    --transition: all 0.3s ease;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    color: var(--text-primary);
    line-height: 1.6;
    padding: 20px;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
}

/* ===========================
   Screen Management
   =========================== */

.screen {
    display: none;
    animation: fadeIn 0.5s ease-in;
}

.screen.active {
    display: block;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ===========================
   Welcome Screen
   =========================== */

#welcome-screen {
    background: var(--bg-white);
    border-radius: var(--border-radius);
    padding: 60px 40px;
    box-shadow: var(--shadow-xl);
    max-width: 800px;
    margin: 0 auto;
}

.welcome-content {
    text-align: center;
}

.logo {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 30px;
    box-shadow: var(--shadow-lg);
}

.logo i {
    font-size: 48px;
    color: white;
}

#welcome-screen h1 {
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 15px;
    font-weight: 800;
}

.subtitle {
    font-size: 1.2rem;
    color: var(--text-secondary);
    margin-bottom: 40px;
}

.welcome-card {
    background: var(--bg-light);
    border-radius: var(--border-radius);
    padding: 30px;
    margin: 30px 0;
    text-align: left;
}

.welcome-card h2 {
    font-size: 1.5rem;
    margin-bottom: 20px;
    color: var(--text-primary);
}

.benefits-list {
    list-style: none;
}

.benefits-list li {
    padding: 12px 0;
    font-size: 1.05rem;
    color: var(--text-secondary);
    display: flex;
    align-items: center;
}

.benefits-list i {
    color: var(--success-color);
    margin-right: 12px;
    font-size: 1.2rem;
}

.time-estimate {
    background: #FEF3C7;
    color: #92400E;
    padding: 12px 20px;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin: 20px 0;
    font-weight: 600;
}

.input-group {
    margin: 25px 0;
    text-align: left;
}

.input-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--text-primary);
    font-size: 1.05rem;
}

.input-group input,
.input-group select {
    width: 100%;
    padding: 15px 20px;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 1rem;
    transition: var(--transition);
    background: white;
}

.input-group input:focus,
.input-group select:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
}

/* ===========================
   Buttons
   =========================== */

.btn-primary,
.btn-secondary {
    padding: 15px 35px;
    font-size: 1.1rem;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin: 10px 5px;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    box-shadow: var(--shadow-md);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.btn-primary:active {
    transform: translateY(0);
}

.btn-secondary {
    background: var(--bg-light);
    color: var(--text-primary);
    border: 2px solid var(--border-color);
}

.btn-secondary:hover {
    background: white;
    border-color: var(--primary-color);
    color: var(--primary-color);
}

.btn-secondary:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

/* ===========================
   Assessment Screen
   =========================== */

#assessment-screen {
    background: var(--bg-white);
    border-radius: var(--border-radius);
    padding: 40px;
    box-shadow: var(--shadow-xl);
    max-width: 900px;
    margin: 0 auto;
}

.assessment-header {
    margin-bottom: 40px;
}

.assessment-header h2 {
    font-size: 1.8rem;
    color: var(--text-primary);
    margin-bottom: 20px;
}

.progress-container {
    display: flex;
    align-items: center;
    gap: 15px;
}

.progress-bar {
    flex: 1;
    height: 12px;
    background: var(--bg-light);
    border-radius: 20px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    border-radius: 20px;
    transition: width 0.5s ease;
    width: 0%;
}

.progress-text {
    font-weight: 700;
    color: var(--primary-color);
    min-width: 50px;
    text-align: right;
}

.chat-container {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
    align-items: flex-start;
}

.chatbot-avatar {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.chatbot-avatar i {
    font-size: 28px;
    color: white;
}

.question-container {
    flex: 1;
    background: var(--bg-light);
    padding: 25px;
    border-radius: var(--border-radius);
}

.question-text {
    font-size: 1.2rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 10px;
}

.question-info {
    font-size: 0.95rem;
    color: var(--text-secondary);
}

.answer-options {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin: 30px 0;
}

.answer-option {
    padding: 20px;
    background: var(--bg-light);
    border: 2px solid var(--border-color);
    border-radius: 8px;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    gap: 15px;
}

.answer-option:hover {
    background: white;
    border-color: var(--primary-color);
    transform: translateX(5px);
}

.answer-option.selected {
    background: linear-gradient(135deg, rgba(79, 70, 229, 0.1), rgba(124, 58, 237, 0.1));
    border-color: var(--primary-color);
    font-weight: 600;
}

.answer-option input[type="radio"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
}

.answer-option label {
    flex: 1;
    cursor: pointer;
    font-size: 1.05rem;
}

.navigation-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 30px;
}

/* ===========================
   Results Screen
   =========================== */

#results-screen {
    background: var(--bg-white);
    border-radius: var(--border-radius);
    padding: 50px;
    box-shadow: var(--shadow-xl);
}

.results-header {
    text-align: center;
    margin-bottom: 50px;
}

.results-header h1 {
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 15px;
}

.results-subtitle {
    font-size: 1.2rem;
    color: var(--text-secondary);
}

.result-section {
    background: var(--bg-light);
    border-radius: var(--border-radius);
    padding: 30px;
    margin-bottom: 30px;
}

.result-section h2 {
    font-size: 1.8rem;
    color: var(--text-primary);
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.result-section h2 i {
    color: var(--primary-color);
}

.section-description {
    color: var(--text-secondary);
    margin-bottom: 20px;
    font-size: 1.05rem;
}

.personality-chart,
.skills-chart {
    background: white;
    padding: 30px;
    border-radius: 8px;
    margin: 20px 0;
}

.trait-bar {
    margin: 20px 0;
}

.trait-label {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;
    font-weight: 600;
}

.trait-progress {
    height: 30px;
    background: var(--bg-light);
    border-radius: 20px;
    overflow: hidden;
    position: relative;
}

.trait-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    border-radius: 20px;
    transition: width 1s ease;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-right: 12px;
    color: white;
    font-weight: 700;
}

.trait-descriptions {
    margin-top: 30px;
}

.trait-description {
    background: white;
    padding: 20px;
    border-radius: 8px;
    margin: 15px 0;
    border-left: 4px solid var(--primary-color);
}

.trait-description h3 {
    color: var(--text-primary);
    margin-bottom: 10px;
}

.trait-description p {
    color: var(--text-secondary);
    line-height: 1.6;
}

.strength-item,
.growth-item {
    background: white;
    padding: 20px;
    border-radius: 8px;
    margin: 15px 0;
    display: flex;
    align-items: flex-start;
    gap: 15px;
}

.strength-item i {
    color: var(--success-color);
    font-size: 1.5rem;
}

.growth-item i {
    color: var(--warning-color);
    font-size: 1.5rem;
}

.career-card {
    background: white;
    padding: 25px;
    border-radius: 8px;
    margin: 20px 0;
    border: 2px solid var(--border-color);
    transition: var(--transition);
}

.career-card:hover {
    border-color: var(--primary-color);
    box-shadow: var(--shadow-md);
}

.career-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.career-title {
    font-size: 1.4rem;
    font-weight: 700;
    color: var(--text-primary);
}

.compatibility-badge {
    background: linear-gradient(135deg, var(--success-color), #059669);
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: 700;
    font-size: 1.1rem;
}

.career-details {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin: 15px 0;
}

.career-detail {
    display: flex;
    align-items: center;
    gap: 10px;
    color: var(--text-secondary);
}

.career-detail i {
    color: var(--primary-color);
}

.career-description {
    color: var(--text-secondary);
    line-height: 1.6;
    margin-top: 15px;
}

.resources-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.resource-card {
    background: white;
    padding: 25px;
    border-radius: 8px;
    text-align: center;
    transition: var(--transition);
    cursor: pointer;
    border: 2px solid var(--border-color);
}

.resource-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-md);
    border-color: var(--primary-color);
}

.resource-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
}

.resource-icon i {
    font-size: 28px;
    color: white;
}

.resource-card h3 {
    font-size: 1.2rem;
    margin-bottom: 10px;
    color: var(--text-primary);
}

.resource-card p {
    color: var(--text-secondary);
    font-size: 0.95rem;
}

.feedback-section {
    text-align: center;
}

.rating-container {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin: 20px 0;
}

.rating-btn {
    font-size: 2.5rem;
    background: none;
    border: none;
    cursor: pointer;
    transition: var(--transition);
    padding: 10px;
}

.rating-btn:hover {
    transform: scale(1.2);
}

.rating-btn.selected {
    transform: scale(1.3);
}

#feedback-text {
    width: 100%;
    max-width: 600px;
    height: 120px;
    padding: 15px;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 1rem;
    font-family: inherit;
    margin: 20px auto;
    display: block;
    resize: vertical;
}

#feedback-text:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
}

.action-buttons {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 15px;
    margin-top: 40px;
}

/* ===========================
   Responsive Design
   =========================== */

@media (max-width: 768px) {
    body {
        padding: 10px;
    }

    #welcome-screen,
    #assessment-screen {
        padding: 30px 20px;
    }

    #results-screen {
        padding: 30px 20px;
    }

    #welcome-screen h1 {
        font-size: 2rem;
    }

    .subtitle {
        font-size: 1rem;
    }

    .results-header h1 {
        font-size: 2rem;
    }

    .chat-container {
        flex-direction: column;
    }

    .navigation-buttons {
        flex-direction: column;
        gap: 10px;
    }

    .btn-primary,
    .btn-secondary {
        width: 100%;
        justify-content: center;
    }

    .career-details {
        grid-template-columns: 1fr;
    }

    .resources-grid {
        grid-template-columns: 1fr;
    }

    .action-buttons {
        flex-direction: column;
    }

    .action-buttons button {
        width: 100%;
    }
}

/* ===========================
   Animations
   =========================== */

@keyframes slideIn {
    from {
        transform: translateX(-20px);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

.answer-option {
    animation: slideIn 0.3s ease forwards;
}

@keyframes pulse {
    0%, 100% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
}

.chatbot-avatar {
    animation: pulse 2s infinite;
}'''

with open('personality-chatbot-webapp/css/styles.css', 'w', encoding='utf-8') as f:
    f.write(css_content)

print("✓ Created styles.css")
