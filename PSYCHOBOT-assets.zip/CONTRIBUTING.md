# Contributing to Personality & Skills Assessment Chatbot

First off, thank you for considering contributing to this project! 🎉

## How Can I Contribute?

### Reporting Bugs
If you find a bug, please create an issue with:
- A clear title and description
- Steps to reproduce the bug
- Expected vs actual behavior
- Screenshots if applicable
- Your browser and OS information

### Suggesting Enhancements
Enhancement suggestions are welcome! Please:
- Use a clear and descriptive title
- Provide detailed explanation of the suggested enhancement
- Explain why this enhancement would be useful
- Include examples if possible

### Pull Requests
1. Fork the repository
2. Create a new branch (`git checkout -b feature/YourFeature`)
3. Make your changes
4. Test thoroughly
5. Commit with clear messages (`git commit -m 'Add: New feature description'`)
6. Push to your branch (`git push origin feature/YourFeature`)
7. Open a Pull Request

## Code Style Guidelines

### JavaScript
- Use meaningful variable and function names
- Add comments for complex logic
- Keep functions focused and modular
- Use ES6+ features where appropriate

### CSS
- Follow existing naming conventions
- Use CSS variables for colors and common values
- Keep selectors specific but not overly complex
- Maintain responsive design principles

### HTML
- Use semantic HTML5 elements
- Maintain proper indentation
- Include ARIA labels for accessibility
- Keep markup clean and organized

## Testing
Before submitting a PR:
- Test on multiple browsers (Chrome, Firefox, Safari, Edge)
- Test on mobile devices or using browser dev tools
- Verify accessibility with screen readers
- Check console for errors

## Questions?
Feel free to open an issue with the "question" label if you need clarification.

Thank you for contributing! 🙏
