
# Create app.js - Main application logic
app_js = '''// Main Application Logic

// Screen Management
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    
    document.getElementById(screenId).classList.add('active');
}

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    console.log('Personality & Skills Assessment Chatbot Initialized');
    console.log('Total Questions:', totalQuestions);
    
    // Add enter key listener for username input
    document.getElementById('username').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const ageSelect = document.getElementById('age');
            if (this.value.trim() && ageSelect.value) {
                startAssessment();
            } else if (this.value.trim()) {
                ageSelect.focus();
            }
        }
    });
    
    // Add change listener for age select
    document.getElementById('age').addEventListener('change', function() {
        const usernameInput = document.getElementById('username');
        if (this.value && usernameInput.value.trim()) {
            // Auto-focus on start button
            document.querySelector('.btn-primary').focus();
        }
    });
});

// Utility Functions
function formatTraitName(trait) {
    if (trait === 'neuroticism') return 'Emotional Stability';
    return trait.charAt(0).toUpperCase() + trait.slice(1);
}

function formatSkillName(skill) {
    return skill.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
}

// Analytics (for demo purposes - logs to console)
function logEvent(eventName, eventData) {
    console.log(`Event: ${eventName}`, eventData);
}

// Error Handling
window.addEventListener('error', function(e) {
    console.error('Application Error:', e.error);
    // In production, send error to logging service
});

// Export functionality for GitHub deployment
console.log('Application ready for GitHub deployment');
console.log('Version: 1.0.0');
console.log('Author: Career Discovery Team');'''

with open('personality-chatbot-webapp/js/app.js', 'w', encoding='utf-8') as f:
    f.write(app_js)

print("✓ Created app.js")
