// Display Results
function displayResults() {
    // Set user name
    document.getElementById('user-name-result').textContent = assessmentState.userName;

    // Display personality profile
    displayPersonalityProfile();

    // Display strengths and growth areas
    displayStrengthsAndGrowth();

    // Display skills profile
    displaySkillsProfile();

    // Display career recommendations
    displayCareerRecommendations();

    // Display resources
    displayResources();
}

function displayPersonalityProfile() {
    const personalityChart = document.getElementById('personality-chart');
    const traitDescriptions = document.getElementById('trait-descriptions');

    const scores = assessmentState.results.personality;

    let chartHTML = '<div class="traits-container">';

    Object.keys(scores).forEach(trait => {
        const score = scores[trait];
        const traitName = trait.charAt(0).toUpperCase() + trait.slice(1);
        const displayName = trait === 'neuroticism' ? 'Emotional Stability' : traitName;

        chartHTML += `
            <div class="trait-bar">
                <div class="trait-label">
                    <span><strong>${displayName}</strong></span>
                    <span>${score}/100</span>
                </div>
                <div class="trait-progress">
                    <div class="trait-fill" style="width: ${score}%">
                        ${score}%
                    </div>
                </div>
            </div>
        `;
    });

    chartHTML += '</div>';
    personalityChart.innerHTML = chartHTML;

    // Display trait descriptions
    let descriptionsHTML = '';

    Object.keys(scores).forEach(trait => {
        const score = scores[trait];
        const data = assessmentData.traitDescriptions[trait];
        let level, description;

        if (score >= 70) {
            level = 'High';
            description = data.high;
        } else if (score >= 40) {
            level = 'Moderate';
            description = data.medium;
        } else {
            level = 'Low';
            description = data.low;
        }

        descriptionsHTML += `
            <div class="trait-description">
                <h3>${data.name} - ${level} (${score}/100)</h3>
                <p>${description}</p>
            </div>
        `;
    });

    traitDescriptions.innerHTML = descriptionsHTML;
}

function displayStrengthsAndGrowth() {
    const strengthsList = document.getElementById('strengths-list');
    const growthAreasList = document.getElementById('growth-areas-list');

    const scores = assessmentState.results.personality;
    const skillsScores = assessmentState.results.skills;

    // Combine personality and skills scores
    const allScores = [];

    Object.keys(scores).forEach(trait => {
        allScores.push({
            name: trait === 'neuroticism' ? 'Emotional Stability' : trait.charAt(0).toUpperCase() + trait.slice(1),
            score: scores[trait],
            type: 'personality'
        });
    });

    Object.keys(skillsScores).forEach(skill => {
        allScores.push({
            name: skill.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
            score: skillsScores[skill],
            type: 'skill'
        });
    });

    // Sort by score
    allScores.sort((a, b) => b.score - a.score);

    // Top 3 strengths
    const strengths = allScores.slice(0, 3);
    let strengthsHTML = '';

    strengths.forEach((strength, index) => {
        const tips = getStrengthTips(strength.name.toLowerCase().replace(/\s+/g, '_'));
        strengthsHTML += `
            <div class="strength-item">
                <i class="fas fa-star"></i>
                <div>
                    <h3>${index + 1}. ${strength.name} (${strength.score}/100)</h3>
                    <p>${tips}</p>
                </div>
            </div>
        `;
    });

    strengthsList.innerHTML = strengthsHTML;

    // Bottom 2 for growth
    const growthAreas = allScores.slice(-2);
    let growthHTML = '';

    growthAreas.forEach((area, index) => {
        const tips = getGrowthTips(area.name.toLowerCase().replace(/\s+/g, '_'));
        growthHTML += `
            <div class="growth-item">
                <i class="fas fa-seedling"></i>
                <div>
                    <h3>${index + 1}. ${area.name} (${area.score}/100)</h3>
                    <p>${tips}</p>
                </div>
            </div>
        `;
    });

    growthAreasList.innerHTML = growthHTML;
}

function getStrengthTips(trait) {
    const tips = {
        'openness': 'Your creativity and curiosity are valuable assets! Channel this into innovative projects, creative problem-solving, and exploring new fields of knowledge.',
        'conscientiousness': 'Your organization and dedication set you apart! Use these skills to lead projects, maintain high standards, and achieve long-term goals.',
        'extraversion': 'Your social energy is a superpower! Leverage it for networking, team leadership, public speaking, and building strong professional relationships.',
        'agreeableness': 'Your empathy and cooperation make you a great team player! Use these strengths in collaborative environments, mentoring, and conflict resolution.',
        'emotional_stability': 'Your emotional resilience is impressive! Use it to handle high-pressure situations, lead during challenges, and support others through difficulties.',
        'problem_solving': 'Your analytical thinking is exceptional! Apply it to complex challenges, strategic planning, and innovative solution development.',
        'communication': 'Your communication skills are outstanding! Use them to influence others, build relationships, present ideas effectively, and lead teams.',
        'leadership': 'Your leadership abilities are strong! Take on leadership roles, mentor others, drive initiatives, and inspire teams toward common goals.',
        'technical': 'Your technical aptitude is remarkable! Continue learning new technologies, solving technical problems, and staying ahead of industry trends.'
    };

    return tips[trait] || 'This is a valuable strength that will serve you well in your career!';
}

function getGrowthTips(trait) {
    const tips = {
        'openness': 'Consider exploring new experiences, trying creative hobbies, or taking courses in unfamiliar subjects to broaden your perspective.',
        'conscientiousness': 'Try using planners or productivity apps, setting specific goals, and establishing routines to build more structure in your work.',
        'extraversion': 'Practice speaking up in meetings, joining group activities, or volunteering for presentations to build social confidence gradually.',
        'agreeableness': 'Work on active listening, practicing empathy, and finding win-win solutions in conflicts to improve collaborative relationships.',
        'emotional_stability': 'Develop stress management techniques like mindfulness, exercise, or talking to a counselor to build emotional resilience.',
        'problem_solving': 'Practice breaking down complex problems, learn analytical frameworks, and work on puzzles or logic exercises to sharpen this skill.',
        'communication': 'Join public speaking groups like Toastmasters, practice active listening, and seek feedback on your communication style.',
        'leadership': 'Start with small leadership opportunities, learn from mentors, read leadership books, and volunteer to lead team projects.',
        'technical': 'Take online courses, practice hands-on projects, join tech communities, and stay curious about new tools and technologies.'
    };

    return tips[trait] || 'Focus on this area through practice, learning, and seeking feedback to develop it over time.';
}

function displaySkillsProfile() {
    const skillsChart = document.getElementById('skills-chart');
    const scores = assessmentState.results.skills;

    let chartHTML = '<div class="skills-container">';

    Object.keys(scores).forEach(skill => {
        const score = scores[skill];
        const skillName = skill.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

        chartHTML += `
            <div class="trait-bar">
                <div class="trait-label">
                    <span><strong>${skillName}</strong></span>
                    <span>${score}/100</span>
                </div>
                <div class="trait-progress">
                    <div class="trait-fill" style="width: ${score}%">
                        ${score}%
                    </div>
                </div>
            </div>
        `;
    });

    chartHTML += '</div>';
    skillsChart.innerHTML = chartHTML;
}

function displayCareerRecommendations() {
    const careersContainer = document.getElementById('career-recommendations');
    const matches = assessmentState.results.careers;

    let careersHTML = '';

    matches.forEach((match, index) => {
        careersHTML += `
            <div class="career-card">
                <div class="career-header">
                    <h3 class="career-title">${index + 1}. ${match.career.title}</h3>
                    <div class="compatibility-badge">${match.compatibility}% Match</div>
                </div>
                <div class="career-details">
                    <div class="career-detail">
                        <i class="fas fa-briefcase"></i>
                        <span>${match.field}</span>
                    </div>
                    <div class="career-detail">
                        <i class="fas fa-chart-line"></i>
                        <span>${match.career.growth} Growth</span>
                    </div>
                    <div class="career-detail">
                        <i class="fas fa-dollar-sign"></i>
                        <span>${match.career.salary} Median Salary</span>
                    </div>
                </div>
                <p class="career-description">${match.career.description}</p>
            </div>
        `;
    });

    careersContainer.innerHTML = careersHTML;
}

function displayResources() {
    const resourcesGrid = document.getElementById('resources-grid');

    let resourcesHTML = '';

    assessmentData.resources.forEach(resource => {
        resourcesHTML += `
            <div class="resource-card" onclick="downloadResource('${resource.title}')">
                <div class="resource-icon">
                    <i class="fas ${resource.icon}"></i>
                </div>
                <h3>${resource.title}</h3>
                <p>${resource.description}</p>
            </div>
        `;
    });

    resourcesGrid.innerHTML = resourcesHTML;
}

// Feedback and Actions
let selectedRating = 0;

function submitRating(rating) {
    selectedRating = rating;

    // Update button styles
    document.querySelectorAll('.rating-btn').forEach((btn, index) => {
        if (index + 1 === rating) {
            btn.classList.add('selected');
        } else {
            btn.classList.remove('selected');
        }
    });
}

function submitFeedback() {
    const feedbackText = document.getElementById('feedback-text').value;

    if (!selectedRating) {
        alert('Please select a rating before submitting 😊');
        return;
    }

    // Store feedback (in real app, send to server)
    console.log('Feedback submitted:', {
        rating: selectedRating,
        feedback: feedbackText,
        userName: assessmentState.userName,
        timestamp: new Date()
    });

    alert('Thank you for your feedback! Your input helps us improve the assessment experience 🙏');

    // Clear form
    document.getElementById('feedback-text').value = '';
    selectedRating = 0;
    document.querySelectorAll('.rating-btn').forEach(btn => btn.classList.remove('selected'));
}

function downloadResource(resourceTitle) {
    alert(`Downloading: ${resourceTitle}\n\nIn a full implementation, this would download a PDF guide.`);
    console.log('Resource download requested:', resourceTitle);
}

function downloadReport() {
    // Generate report content
    const reportContent = generateReportContent();

    // In a real implementation, this would generate a PDF
    // For demo purposes, we'll create a text file
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${assessmentState.userName.replace(/\s+/g, '_')}_Assessment_Report.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    alert('Your assessment report has been downloaded! 📄');
}

function generateReportContent() {
    const results = assessmentState.results;
    const date = new Date().toLocaleDateString();

    let report = `
═══════════════════════════════════════════════════════
PERSONALITY & SKILLS ASSESSMENT REPORT
═══════════════════════════════════════════════════════

Name: ${assessmentState.userName}
Age Group: ${assessmentState.userAge}
Date: ${date}

═══════════════════════════════════════════════════════
PERSONALITY PROFILE (Big Five Model)
═══════════════════════════════════════════════════════

`;

    Object.keys(results.personality).forEach(trait => {
        const score = results.personality[trait];
        const name = trait === 'neuroticism' ? 'Emotional Stability' : trait.charAt(0).toUpperCase() + trait.slice(1);
        report += `${name}: ${score}/100\n`;
    });

    report += `\n═══════════════════════════════════════════════════════
SKILLS PROFILE
═══════════════════════════════════════════════════════

`;

    Object.keys(results.skills).forEach(skill => {
        const score = results.skills[skill];
        const name = skill.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
        report += `${name}: ${score}/100\n`;
    });

    report += `\n═══════════════════════════════════════════════════════
TOP CAREER RECOMMENDATIONS
═══════════════════════════════════════════════════════

`;

    results.careers.forEach((match, index) => {
        report += `${index + 1}. ${match.career.title} (${match.compatibility}% Match)
   Field: ${match.field}
   Growth Rate: ${match.career.growth}
   Median Salary: ${match.career.salary}

`;
    });

    report += `\n═══════════════════════════════════════════════════════
This assessment is designed to help you understand your
personality traits and skills to make informed career
decisions. For best results, consult with a career
counselor to discuss your options in detail.
═══════════════════════════════════════════════════════
`;

    return report;
}

function restartAssessment() {
    if (confirm('Are you sure you want to restart the assessment? Your current results will be lost.')) {
        // Reset state
        assessmentState = {
            currentPhase: 'personality',
            currentQuestionIndex: 0,
            responses: {},
            userName: '',
            userAge: '',
            startTime: null,
            endTime: null
        };

        // Clear inputs
        document.getElementById('username').value = '';
        document.getElementById('age').value = '';

        // Show welcome screen
        showScreen('welcome-screen');
    }
}