
import zipfile
import os

# Create a ZIP file with all the webapp files
def create_zip():
    zip_filename = 'personality-skills-chatbot.zip'
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Walk through the directory
        for root, dirs, files in os.walk('personality-chatbot-webapp'):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = file_path.replace('personality-chatbot-webapp/', '')
                zipf.write(file_path, arcname)
                print(f"  Added: {arcname}")
    
    return zip_filename

print("\n" + "="*60)
print("Creating ZIP file for GitHub deployment...")
print("="*60 + "\n")

zip_file = create_zip()

print("\n" + "="*60)
print("✅ ZIP file created successfully!")
print("="*60)

# Get file size
file_size = os.path.getsize(zip_file)
file_size_kb = file_size / 1024

print(f"\nFile: {zip_file}")
print(f"Size: {file_size_kb:.2f} KB ({file_size} bytes)")

# List all files in the project
print("\n" + "="*60)
print("PROJECT STRUCTURE")
print("="*60 + "\n")

file_count = 0
for root, dirs, files in os.walk('personality-chatbot-webapp'):
    level = root.replace('personality-chatbot-webapp', '').count(os.sep)
    indent = ' ' * 2 * level
    print(f"{indent}{os.path.basename(root)}/")
    subindent = ' ' * 2 * (level + 1)
    for file in files:
        print(f"{subindent}{file}")
        file_count += 1

print(f"\nTotal files: {file_count}")

print("\n" + "="*60)
print("NEXT STEPS FOR GITHUB")
print("="*60)
print("""
1. Create a new repository on GitHub:
   - Go to https://github.com/new
   - Name: personality-skills-chatbot
   - Description: A comprehensive personality & skills assessment chatbot
   - Public repository
   - Don't initialize with README (we have one)

2. Extract the ZIP file to a local directory

3. Initialize Git and push to GitHub:
   
   cd personality-skills-chatbot
   git init
   git add .
   git commit -m "Initial commit: Personality & Skills Assessment Chatbot"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/personality-skills-chatbot.git
   git push -u origin main

4. Enable GitHub Pages:
   - Go to repository Settings > Pages
   - Source: Deploy from a branch
   - Branch: main / root
   - Save

5. Your app will be live at:
   https://YOUR_USERNAME.github.io/personality-skills-chatbot/

6. Update README.md:
   - Replace YOUR_USERNAME with your actual GitHub username
   - Update contact information
   - Add screenshots if desired
""")

print("="*60)
print("✨ All files ready for GitHub deployment!")
print("="*60)
