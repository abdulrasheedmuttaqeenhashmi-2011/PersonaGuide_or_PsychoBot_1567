
import os
import zipfile
from datetime import datetime

# Create directory structure
os.makedirs('personality-chatbot-webapp', exist_ok=True)
os.makedirs('personality-chatbot-webapp/css', exist_ok=True)
os.makedirs('personality-chatbot-webapp/js', exist_ok=True)
os.makedirs('personality-chatbot-webapp/assets', exist_ok=True)
os.makedirs('personality-chatbot-webapp/data', exist_ok=True)

print("Created directory structure successfully!")
print("\nGenerating application files...")
