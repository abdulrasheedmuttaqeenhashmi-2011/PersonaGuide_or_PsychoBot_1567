
# Create .gitignore file
gitignore_content = '''# OS files
.DS_Store
Thumbs.db

# Editor files
.vscode/
.idea/
*.sublime-project
*.sublime-workspace

# Node modules (if using npm for any tooling)
node_modules/

# Logs
*.log
npm-debug.log*

# Environment variables
.env
.env.local

# Build outputs
dist/
build/

# Temporary files
*.tmp
*.temp
'''

with open('personality-chatbot-webapp/.gitignore', 'w', encoding='utf-8') as f:
    f.write(gitignore_content)

print("✓ Created .gitignore")
